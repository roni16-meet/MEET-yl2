**********************************************
HG DESIGNS

PERSONAL USE OF THESE  files includes:

* USING MY ITEMS TO DESIGN YOUR OWN DIGITAL SCRAPBOOK ITEMS YOU ***DO NOT*** SELL THAT ARE FOR YOUR OWN PERSONAL USE.
* DESIGNING SCRAPBOOK PAGES/DESIGNS/ITEMS THAT YOU USE TO CREATE SCRAPBOOK PAGES FOR OTHERS (S4H/S4O)

PLEASE READ!!!
--------------
--------------
--------------

*****COMMERCIAL USE OF THESE files IS ONLY ALLOWED WITH A ***PAID*** COMMERCIAL USE LICENSE AVAILBLE ON THE BLOG
AT http://cesstrelle.wordpress.com  (see top of blog for link to page for info)
YOU MUST ***PAY*** FOR THE LICENSE BEFORE USING THESE ITEMS TO CREATE ANYTHING AT ALL FOR RESALE!!!

________________________________________________________________________________________________________________
***PLEASE NOTE: IF THE ITEM DESCRIPTION ON THE BLOG STATES THAT YOU DO NOT NEED THE COMMERCIAL USE LICENSE
YOU CAN VOID THE STATEMENT ABOVE BUT ABIDE BY THE NEXT STATEMENT BELOW.  
________________________________________________________________________________________________________________


DO NOT RESELL THESE AS THEY ARE AND CLAIM AS YOUR OWN

You may not share these graphics, zip files or folders (together or separately) with anyone else, if someone is interested in these graphics
then please direct them to the location in which you downloaded the graphics so they may download it themselves.

You may not use these files for obscene, defamatory, hate, bigotry, racism, animal abuse or immoral works or any other purpose which 
is prohibited by law.



Thank you for reading my conditions. 


For any further questions, please e-mail me at
cesstrelle@aol.com
***PLEASE put HG DESIGNS IN THE SUBJECT LINE SO I KNOW IT'S NOT SPAM

Or visit my blog for more freebies at:
http://cesstrelle.wordpress.com



Enjoy!

HG DESIGNS
